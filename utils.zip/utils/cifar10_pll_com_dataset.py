import torch
from torch.utils.data import Dataset
import torchvision.transforms as transforms
import torchvision.datasets as dsets
from .randaugment import RandomAugment
from .utils_algo import generate_uniform_cv_candidate_labels,  generate_compl_labels


def load_cifar10(partial_rate, batch_size):
    temp_train = dsets.CIFAR10(root='./data', train=True, download=True, transform=transforms.ToTensor())
    data_train, labels_train = temp_train.data, torch.Tensor(temp_train.targets).long()

    data_train1 = data_train[20000:50000, :, :, :]
    labels_train1 = labels_train[20000:50000]
    data_train2 = data_train[:20000, :, :, :]
    labels_train2 = labels_train[:20000]

    partialY_train = generate_uniform_cv_candidate_labels(labels_train1, partial_rate)
    compleY_train, complelabels = generate_compl_labels(labels_train2)

    temp_train1 = torch.zeros(partialY_train.shape)
    temp_train1[torch.arange(partialY_train.shape[0]), labels_train1] = 1
    if torch.sum(partialY_train * temp_train1) == partialY_train.shape[0]:
        print('partialY correctly loaded')
    else:
        print('inconsistent permutation')
    print('Average candidate num: ', partialY_train.sum(1).mean())
    partial_matrix_dataset_train = CIFAR10_Augmentention_change(data_train1, partialY_train, labels_train1)
    comple_matrix_dataset_train = CIFAR10_Augmentention_change_comple(data_train2, compleY_train, labels_train2, complelabels)

    # test dataset
    test_transform = transforms.Compose(
        [transforms.ToTensor(),
         transforms.Normalize((0.4914, 0.4822, 0.4465), (0.247, 0.243, 0.261))])
    partial_matrix_dataset_test = dsets.CIFAR10(root='./data', train=False, transform=test_transform)

    partial_matrix_train_loader1 = torch.utils.data.DataLoader(dataset=partial_matrix_dataset_train,
        batch_size=batch_size,
        shuffle=True,
        num_workers=8,
        pin_memory=True,
        drop_last=True)

    partial_matrix_train_loader2 = torch.utils.data.DataLoader(dataset=comple_matrix_dataset_train,
                                                           batch_size=batch_size,
                                                           shuffle=True,
                                                           num_workers=8,
                                                           pin_memory=True,
                                                           drop_last=True)

    partial_matrix_test_loader = torch.utils.data.DataLoader(dataset=partial_matrix_dataset_test,
                                                              batch_size=batch_size,
                                                              shuffle=True,
                                                              num_workers=8,
                                                              pin_memory=True,
                                                              drop_last=False)

    return data_train1, labels_train1, partialY_train, partial_matrix_dataset_train, data_train2, labels_train2,  compleY_train, comple_matrix_dataset_train, partial_matrix_train_loader1,  partial_matrix_train_loader2,  partial_matrix_test_loader,  complelabels




def generate_dataloader_partial(data_train, labels_train, partialY_train, batch_size):
    partial_matrix_dataset_train = CIFAR10_Augmentention_change(data_train, partialY_train.float(), labels_train.float())
    partial_matrix_train_loader = torch.utils.data.DataLoader(dataset=partial_matrix_dataset_train,
        batch_size=batch_size,
        shuffle=True,
        drop_last=True)
    return partial_matrix_train_loader



def generate_dataloader_comple(data_train, labels_train, partialY_train, complemen_lab,  batch_size):
    partial_matrix_dataset_train = CIFAR10_Augmentention_change_comple(data_train, partialY_train.float(), labels_train.float(), complemen_lab)
    partial_matrix_train_loader = torch.utils.data.DataLoader(dataset=partial_matrix_dataset_train,
        batch_size=batch_size,
        shuffle=True,
        drop_last=True)
    return partial_matrix_train_loader


class CIFAR10_Augmentention_change(Dataset):
    def __init__(self, images, given_label_matrix, true_labels):
        self.images = images
        self.given_label_matrix = given_label_matrix
        self.true_labels = true_labels
        self.weak_transform = transforms.Compose(
            [
                transforms.ToPILImage(),
                transforms.RandomResizedCrop(size=32, scale=(0.2, 1.)),
                transforms.RandomHorizontalFlip(),
                transforms.RandomApply([
                    transforms.ColorJitter(0.4, 0.4,  0.4, (0.5, 0.5))
                ], p=0.8),
                transforms.RandomGrayscale(p=0.2),
                transforms.ToTensor(),
                transforms.Normalize((0.4914, 0.4822, 0.4465), (0.247, 0.243, 0.261))])
        self.strong_transform = transforms.Compose(
            [
                transforms.ToPILImage(),
                transforms.RandomResizedCrop(size=32, scale=(0.2, 1.)),
                transforms.RandomHorizontalFlip(),
                        transforms.RandomApply([
                            transforms.ColorJitter(0.4,  0.4,  0.4, (0.25, 0.25))
                        ], p=0.8),
                        transforms.RandomGrayscale(p=0.2),
                transforms.ToTensor(),
                transforms.Normalize((0.4914, 0.4822, 0.4465), (0.247, 0.243, 0.261))])

    def __len__(self):
           return len(self.true_labels)

    def __getitem__(self, index):

         each_image_w = self.weak_transform(self.images[index])
         each_label = self.given_label_matrix[index]
         each_true_label = self.true_labels[index]
         images1 = self.images[index]
         return images1, each_image_w,  each_label, each_true_label, index


class CIFAR10_Augmentention_change_comple(Dataset):
    def __init__(self, images, given_label_matrix, true_labels, comple_labels):
        self.images = images
        self.given_label_matrix = given_label_matrix
        self.true_labels = true_labels
        self.comple_labels = comple_labels
        self.weak_transform = transforms.Compose(
            [
                transforms.ToPILImage(),
                transforms.RandomResizedCrop(size=32, scale=(0.2, 1.)),
                transforms.RandomHorizontalFlip(),
                transforms.RandomApply([
                    transforms.ColorJitter(0.4, 0.4,  0.4, (0.5, 0.5))
                ], p=0.8),
                transforms.RandomGrayscale(p=0.2),
                transforms.ToTensor(),
                transforms.Normalize((0.4914, 0.4822, 0.4465), (0.247, 0.243, 0.261))])
        self.strong_transform = transforms.Compose(
            [
                transforms.ToPILImage(),
                transforms.RandomResizedCrop(size=32, scale=(0.2, 1.)),
                transforms.RandomHorizontalFlip(),
                        transforms.RandomApply([
                            transforms.ColorJitter(0.4,  0.4,  0.4, (0.25, 0.25))
                        ], p=0.8),
                        transforms.RandomGrayscale(p=0.2),
                transforms.ToTensor(),
                transforms.Normalize((0.4914, 0.4822, 0.4465), (0.247, 0.243, 0.261))])

    def __len__(self):
           return len(self.true_labels)

    def __getitem__(self, index):
                each_image_w = self.weak_transform(self.images[index])
                each_label = self.given_label_matrix[index]
                each_true_label = self.true_labels[index]
                comple_labels = self.comple_labels[index]
                images1 = self.images[index]
                return images1, each_image_w, each_label, each_true_label, index, comple_labels