import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import math
import pickle
from numpy import *

class AverageMeter(object):
    """Computes and stores the average and current value"""
    def __init__(self, name, fmt=':f'):
        self.name = name
        self.fmt = fmt
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count

    def __str__(self):
        fmtstr = '{name} {val' + self.fmt + '} ({avg' + self.fmt + '})'
        return fmtstr.format(**self.__dict__)


class ProgressMeter(object):
    def __init__(self, num_batches, meters, prefix=""):
        self.batch_fmtstr = self._get_batch_fmtstr(num_batches)
        self.meters = meters
        self.prefix = prefix

    def display(self, batch):
        entries = [self.prefix + self.batch_fmtstr.format(batch)]
        entries += [str(meter) for meter in self.meters]
        print('\t'.join(entries))

    def _get_batch_fmtstr(self, num_batches):
        num_digits = len(str(num_batches // 1))
        fmt = '{:' + str(num_digits) + 'd}'
        return '[' + fmt + '/' + fmt.format(num_batches) + ']'

def adjust_learning_rate(args, optimizer, epoch):
    lr = args.lr
    if args.cosine:
        eta_min = lr * (args.lr_decay_rate ** 3)
        lr = eta_min + (lr - eta_min) * (
                1 + math.cos(math.pi * epoch / args.epochs)) / 2
    else:
        steps = np.sum(epoch > np.asarray(args.lr_decay_epochs))
        if steps > 0:
            lr = lr * (args.lr_decay_rate ** steps)

    for param_group in optimizer.param_groups:
        param_group['lr'] = lr


def accuracy(output, target, topk=(1,)):
    """Computes the accuracy over the k top predictions for the specified values of k"""
    with torch.no_grad():
        maxk = max(topk)
        batch_size = target.size(0)

        _, pred = output.topk(maxk, 1, True, True)
        pred = pred.t()
        correct = pred.eq(target.view(1, -1).expand_as(pred))

        res = []
        for k in topk:
            correct_k = correct[:k].reshape((-1, )).float().sum(0, keepdim=True)
            res.append(correct_k.mul_(100.0 / batch_size))
        return res



def accuracy_comple(args, loader, model, threshold):
    sm = F.softmax
    partial_labels_right = torch.rand(1, 10)
    labels_right = torch.rand(1)
    images_right = zeros([1, 32, 32, 3]).astype(np.uint8)
    partial_labels_wrong = torch.rand(1, 10)
    labels_wrong = torch.rand(1)
    images_wrong = zeros([1, 32, 32, 3]).astype(np.uint8)
    can_generate = torch.rand(1)

    for batch_index, (images, images_w,  complementary_matrix, labels, _, complementary_label) in enumerate(loader): #看CIFAR10_Augmentention_change_comple(Dataset)中return的东西
        with torch.no_grad():
            X_w,  labels = images_w.cuda(),  labels.cuda()
            outputs = model(X_w, args, eval_only=True)
            sm_outputs = sm(outputs, dim=1)
            value, predicted = torch.max(sm_outputs.data, 1)
            labels = labels.long()

            print('record')
            for j in range(256):
                if value[j] > threshold and predicted[j] != complementary_label[j]:
                    c = torch.zeros(1, 10)
                    c[0, predicted[j]] = 1
                    partial_labels_right = torch.cat([partial_labels_right, c], dim=0)
                    e1 = zeros([1, 32, 32, 3])
                    e1[0, :, :, :] = images[j, :, :, :]
                    e1 = e1.astype(np.uint8)
                    images_right = np.concatenate([images_right, e1], axis=0)
                    labels_right = torch.cat(
                        [labels_right, torch.tensor(np.expand_dims(labels[j].cpu(), 0))], dim=0)
                else:
                    e3 = torch.zeros(1, 10)
                    e3[0, :] = complementary_matrix[j, :]
                    partial_labels_wrong = torch.cat([partial_labels_wrong, e3], dim=0)
                    e2 = zeros([1, 32, 32, 3])
                    e2[0, :, :, :] = images[j, :, :, :]
                    e2 = e2.astype(np.uint8)
                    images_wrong = np.concatenate([images_wrong, e2], axis=0)
                    labels_wrong = torch.cat(
                        [labels_wrong, torch.tensor(np.expand_dims(labels[j].cpu(), 0))], dim=0)
                    can_generate = torch.cat([can_generate,torch.tensor(np.expand_dims(complementary_label[j].cpu(),0))], dim=0)

    return partial_labels_right, images_right, labels_right, partial_labels_wrong, images_wrong, labels_wrong, can_generate



def sigmoid_rampup(current, rampup_length, exp_coe=5.0):
    """Exponential rampup from https://arxiv.org/abs/1610.02242"""
    if rampup_length == 0:
        return 1.0
    else:
        current = np.clip(current, 0.0, rampup_length)
        phase = 1.0 - current / rampup_length
        return float(np.exp(-exp_coe * phase * phase))


def linear_rampup(current, rampup_length):
    """Linear rampup"""
    assert current >= 0 and rampup_length >= 0
    if current >= rampup_length:
        return 1.0
    else:
        return current / rampup_length


def cosine_rampdown(current, rampdown_length):
    """Cosine rampdown from https://arxiv.org/abs/1608.03983"""
    assert 0 <= current <= rampdown_length
    return float(.5 * (np.cos(np.pi * current / rampdown_length) + 1))



def generate_uniform_cv_candidate_labels(train_labels, partial_rate=0.5):
    """ 产生偏标记矩阵 """
    if torch.min(train_labels) > 1:
        raise RuntimeError('testError')
    elif torch.min(train_labels) == 1:
        train_labels = train_labels - 1

    K = int(torch.max(train_labels) - torch.min(train_labels) + 1)
    n = train_labels.shape[0]

    partialY = torch.zeros(n, K)
    partialY[torch.arange(n), train_labels] = 1.0
    p_1 = partial_rate
    transition_matrix =  np.eye(K)
    transition_matrix[np.where(~np.eye(transition_matrix.shape[0],dtype=bool))]=p_1

    random_n = np.random.uniform(0, 1, size=(n, K))

    for j in range(n):
        for jj in range(K):
            if jj == train_labels[j]:
                continue
            if random_n[j, jj] < transition_matrix[train_labels[j], jj]:
                partialY[j, jj] = 1.0

    print("Finish Generating Candidate Label Sets!\n")
    return partialY



def generate_compl_labels(train_labels):
    K = torch.max(train_labels)+1
    candidates = np.arange(K)
    candidates = np.repeat(candidates.reshape(1, K), len(train_labels), 0)
    mask = np.ones((len(train_labels), K), dtype=bool)
    mask[range(len(train_labels)), train_labels.numpy()] = False
    candidates_ = candidates[mask].reshape(len(train_labels), K-1)
    idx = np.random.randint(0, K-1, len(train_labels))
    complementary_la_1 = candidates_[np.arange(len(train_labels)), np.array(idx)]
    can = np.ones((len(train_labels), K))
    can[range(len(train_labels)), complementary_la_1] =0
    return can, complementary_la_1

def unpickle(file):
    with open(file, 'rb') as fo:
        res = pickle.load(fo, encoding='bytes')
    return res



def generate_hierarchical_cv_candidate_labels(dataname, train_labels, partial_rate=0.1):
    assert dataname == 'cifar100'

    meta = unpickle('data/cifar-100-python/meta')

    fine_label_names = [t.decode('utf8') for t in meta[b'fine_label_names']]
    label2idx = {fine_label_names[i]:i for i in range(100)}

    x = '''aquatic mammals#beaver, dolphin, otter, seal, whale
fish#aquarium fish, flatfish, ray, shark, trout
flowers#orchid, poppy, rose, sunflower, tulip
food containers#bottle, bowl, can, cup, plate
fruit and vegetables#apple, mushroom, orange, pear, sweet pepper
household electrical devices#clock, keyboard, lamp, telephone, television
household furniture#bed, chair, couch, table, wardrobe
insects#bee, beetle, butterfly, caterpillar, cockroach
large carnivores#bear, leopard, lion, tiger, wolf
large man-made outdoor things#bridge, castle, house, road, skyscraper
large natural outdoor scenes#cloud, forest, mountain, plain, sea
large omnivores and herbivores#camel, cattle, chimpanzee, elephant, kangaroo
medium-sized mammals#fox, porcupine, possum, raccoon, skunk
non-insect invertebrates#crab, lobster, snail, spider, worm
people#baby, boy, girl, man, woman
reptiles#crocodile, dinosaur, lizard, snake, turtle
small mammals#hamster, mouse, rabbit, shrew, squirrel
trees#maple_tree, oak_tree, palm_tree, pine_tree, willow_tree
vehicles 1#bicycle, bus, motorcycle, pickup truck, train
vehicles 2#lawn_mower, rocket, streetcar, tank, tractor'''

    x_split = x.split('\n')
    hierarchical = {}
    reverse_hierarchical = {}
    hierarchical_idx = [None] * 20
    reverse_hierarchical_idx = [None] * 100
    super_classes = []
    labels_by_h = []
    for i in range(len(x_split)):
        s_split = x_split[i].split('#')
        super_classes.append(s_split[0])
        hierarchical[s_split[0]] = s_split[1].split(', ')
        for lb in s_split[1].split(', '):
            reverse_hierarchical[lb.replace(' ', '_')] = s_split[0]
            
        labels_by_h += s_split[1].split(', ')
        hierarchical_idx[i] = [label2idx[lb.replace(' ', '_')] for lb in s_split[1].split(', ')]
        for idx in hierarchical_idx[i]:
            reverse_hierarchical_idx[idx] = i

    # end generate hierarchical
    if torch.min(train_labels) > 1:
        raise RuntimeError('testError')
    elif torch.min(train_labels) == 1:
        train_labels = train_labels - 1

    K = int(torch.max(train_labels) - torch.min(train_labels) + 1)
    n = train_labels.shape[0]

    partialY = torch.zeros(n, K)
    partialY[torch.arange(n), train_labels] = 1.0
    p_1 = partial_rate
    transition_matrix =  np.eye(K)
    transition_matrix[np.where(~np.eye(transition_matrix.shape[0],dtype=bool))]=p_1
    mask = np.zeros_like(transition_matrix)
    for i in range(len(transition_matrix)):
        superclass = reverse_hierarchical_idx[i]
        subclasses = hierarchical_idx[superclass]
        mask[i, subclasses] = 1

    transition_matrix *= mask
    print(transition_matrix)

    random_n = np.random.uniform(0, 1, size=(n, K))

    for j in range(n):
        for jj in range(K):
            if jj == train_labels[j]:
                continue
            if random_n[j, jj] < transition_matrix[train_labels[j], jj]:
                partialY[j, jj] = 1.0
    print("Finish Generating Candidate Label Sets!\n")
    return partialY